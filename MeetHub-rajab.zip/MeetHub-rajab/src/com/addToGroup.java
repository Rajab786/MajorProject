package com;
import java.util.ArrayList;
import java.util.List;

public class addToGroup {
  public String university;
  public String name;
  public String file;
  public String status;
  public String Date;
  public String Time;
  public String accessSpecifier;

	public void setuniversity(String university) {
		this.university = university;
	}
	public String getuniversity() {
      return university;
  }
	public void setname(String name) {
		this.name = name;
	}
  public String getname() {
      return name;
  }
  public void setfile(String file) {
		this.file = file;
	}
	public String getfile() {
      return file;
  }
  public void setstatus(String status) {
		this.status = status;
	}
  public String getstatus() {
      return status;
  }
  public void setDate(String Date) {
		this.Date = Date;
	}
	public String getDate() {
      return Date;
  }
  public void setTime(String Time) {
		this.Time = Time;
	}
	public String getTime() {
      return Time;
  }
  public void setaccessSpecifier(String accessSpecifier) {
		this.accessSpecifier = accessSpecifier;
	}
	public String getaccessSpecifier() {
      return accessSpecifier;
  }
  
  

}
